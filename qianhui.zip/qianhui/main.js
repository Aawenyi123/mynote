import Vue from 'vue'
import App from './App'

Vue.config.productionTip = false
Vue.prototype.serverUrl = 'https://www.wentang.online';
// Vue.prototype.serverUrl = 'http://www.mynote.com';
// Vue.prototype.serverUrl = 'http://127.0.0.1';
Vue.prototype.appid = 'bc4512dc898f8a8832c5f2a520b66435';

App.mpType = 'app'

const app = new Vue({
	...App
})
app.$mount()
