<template>
	<view class="container">
		<!-- // 适应刘海屏幕 -->
		<view class="top" :style="{backgroundColor: '#0FD690',height: iStatusBarHeight + 'px'}"></view>
		<view class="header">
			
			<view class="title">
				展示笔记（{{noteList.length}}）条
			</view>
			<view class="search-block">
				<image src="../../static/icos/search.png" class="search-icon"></image>
				<input type="text" class="search" v-model="search" placeholder="搜手记" @confirm="searchNotes"/>
			</view>
		</view>
		<view class="noteList">
			<view>
				<view v-for="(note, index) in noteList" :key="index">
					
					<view class="note-date" v-show="isShow(note)">
						{{note.create_at.substr(0, 10)}}
					</view>
					<view class="note-block" @click="getInfo(note.id)">
						<view class="tag-block">
							<image src="../../static/tabBarIco/cate-b.jpg" class="tag-icon"></image>
							<view class="tag-name">{{note.cate_name}}</view>
						</view>
						<view class="note-top">
							<view class="note-time">{{note.create_at.substr(11,8)}}</view>
							<view class="note-title">{{note.title}}</view>
						</view>
						<view class="note-content">
							{{note.minContent ? note.minContent.substr(0,20):''}}...
						</view>
					</view>
				</view>
			</view>
			
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				totalNum: 11,
				search: '',
				iStatusBarHeight: 0,
				dateList: [],
				noteList: [],
				page: 1
			}
		},
		methods: {
			searchNotes: function () {
				// console.log(this.search);
				this.dateList = [];
				this.noteList = [];
				this.page = 1;
				var me = this;
				console.log(me.page);
				uni.request({
					url: me.serverUrl + '/note/notelist',
					method: 'GET',
					data: {
						appid: me.appid,
						creatorId: me.creatorId,
						appid: me.appid,
						page: me.page,
						search: me.search
					},
					success: function (res) {
						console.log(res);
						if (res.data.status == 200) {
							// me.cateList = res.data.data;
							me.noteList = res.data.data;
							return false;
						}
						uni.showToast({title: res.data.msg, icon: 'none', duration: 1000});
					},
					fail: function () {
						uni.showToast({title: '请求失败', icon: 'none', duration: 1000});
					}
				});
			},
			getInfo(id) {
				// console.log('跳转info页');
				uni.navigateTo({
					url: '../info/info?noteId=' + id
				});
			},
			checkLogin() {
				var globalUser = uni.getStorageSync('globalUser');
				if (!globalUser) {
					uni.navigateTo({
						url: '/pages/login/login'
					});
				}
				// console.log(globalUser);
				// 修改
				
			},
			isShow(note) {
				var date = note.create_at.substr(0, 10);
				// console.log(this.dateList.indexOf(date));
				// console.log(this.dateList);
				if (this.dateList[date] == 1) {
					return false;
				} else {
					// this.dateList.push(date);
					this.dateList[date] = 1;
					return true;
				}
			}
		},
		onShow() {
			this.checkLogin();
			var globalUser = uni.getStorageSync('globalUser');
			this.creatorId = globalUser.id;
			var me = this;
			setTimeout(function () {
				me.searchNotes();
			}, 300);
			
			
		},
		onLoad() {
			// 适应刘海屏幕 获取状态栏的高度
			this.iStatusBarHeight = uni.getSystemInfoSync().statusBarHeight;
			// console.log(this.iStatusBarHeight);
		},
		onReachBottom() {
			var me = this;
			console.log('上拉加载下一页数据');
			// 加载数据再拼接
			// me.imgList = me.imgList.concat(me.imgList);
			me.page += 1;
			var me = this;
			uni.request({
				url: me.serverUrl + '/note/notelist',
				method: 'GET',
				data: {
					appid: me.appid,
					creatorId: me.creatorId,
					appid: me.appid,
					page: me.page,
					search: me.search
				},
				success: function (res) {
					console.log(res);
					if (res.data.status == 200 && res.data.data.length > 0) {
						// me.cateList = res.data.data;
						// me.noteList = res.data.data;
						me.tmp = me.noteList;
						me.dateList = [];
						
						me.noteList = [];
						me.noteList = me.tmp.concat(res.data.data);
						return false;
					}
					// uni.showToast({title: res.data.msg, icon: 'none', duration: 1000});
				},
				fail: function () {
					uni.showToast({title: '请求失败', icon: 'none', duration: 1000});
				}
			});
		}
	}
</script>

<style>
	@import url('./index.css');
</style>
