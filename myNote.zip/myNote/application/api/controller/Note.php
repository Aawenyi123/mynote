<?php

/**
 * @Author: wenyi
 * @Date:   2020-05-18 09:11:14
 * @Email: m17600903720@163.com
 * @Tel: 17600903720
 * @Comment: comment...
 * @CreateTime: 2020-05-18 09:11:14
 */
namespace app\api\controller;
use think\Db;
use think\Controller;
class Note extends Controller {
	public function add() {
		$creatorId = intval(input('post.creatorId'));
		$token = trim(input('post.token'));
		$appid = trim(input('post.appid'));
		$title = trim(input('post.title'));
		$cateId = intval(input('post.cateId'));
		$content = trim(input('post.content'));
		$minContent = trim(input('post.minContent'));
		$checkToken = Db::table('securet')
						->where('appid', $appid)
						->find();
		if (!$checkToken) {
			return json([
				'status' => 405,
				'msg' => '非法访问'
			]);
		}
		if (!$creatorId || !$token || !$title || !$cateId || !$content) {
			return json([
				'status' => 405,
				'msg' => '传参不能为空'
			]);
		}
		// 检测用户
		$user = Db::table('user')
				->where('id', $creatorId)
				->where('token', $token)
				->find();
		if (!$user) {
			return json([
				'status' => 405,
				'msg' => '非法用户访问'
			]);
		}
		$res = Db::table('note')
				->insertGetId([
					'title' => $title,
					'cate_id' => $cateId,
					'content' => $content,
					'creator_id' => $creatorId,
					'create_at' => date('Y-m-d H:i:s'),
					'minContent' => $minContent
				]);
		if ($res) {
			return json([
				'status' => 200,
				'msg' => '添加手记成功'
			]);
		}
		return json([
			'status' => 405,
			'msg' => '添加手机失败'
		]);
	}
	public function delete() {
		$creatorId = intval(input('post.creatorId'));
		$token = trim(input('post.token'));
		$appid = trim(input('post.appid'));
		$noteId = intval(input('post.noteId'));
		$checkToken = Db::table('securet')
						->where('appid', $appid)
						->find();
		if (!$checkToken) {
			return json([
				'status' => 405,
				'msg' => '非法访问'
			]);
		}
		if (!$creatorId || !$token || !$noteId) {
			return json([
				'status' => 405,
				'msg' => '传参不能为空'
			]);
		}
		// 检测用户
		$user = Db::table('user')
				->where('id', $creatorId)
				->where('token', $token)
				->find();
		if (!$user) {
			return json([
				'status' => 405,
				'msg' => '非法用户访问'
			]);
		}
		$res = Db::table('note')
				->where('id', $noteId)
				->where('creator_id', $creatorId)
				->update([
					'deleted' => 1
				]);
		return json([
			'status' => 200,
			'msg' => '删除手记成功'
		]);
	}
	public function update() {
		$creatorId = intval(input('post.creatorId'));
		$token = trim(input('post.token'));
		$appid = trim(input('post.appid'));
		$title = trim(input('post.title'));
		$cateId = intval(input('post.cateId'));
		$content = trim(input('post.content'));
		$noteId = intval(input('post.noteId'));
		$minContent = trim(input('post.minContent'));
		$checkToken = Db::table('securet')
						->where('appid', $appid)
						->find();
		if (!$checkToken) {
			return json([
				'status' => 405,
				'msg' => '非法访问'
			]);
		}
		if (!$creatorId || !$token || !$title || !$cateId || !$content || !$noteId) {
			return json([
				'status' => 405,
				'msg' => '传参不能为空'
			]);
		}
		// 检测用户
		$user = Db::table('user')
				->where('id', $creatorId)
				->where('token', $token)
				->find();
		if (!$user) {
			return json([
				'status' => 405,
				'msg' => '非法用户访问'
			]);
		}
		// 修改
		$info = Db::table('note')
				->where('id', $noteId)
				->where('title', $title)
				->where('cate_id', $cateId)
				->where('content', $content)
				->where('creator_id', $creatorId)
				->where('deleted', 0)
				->find();
		if ($info) {
			return json([
				'status' => 200,
				'msg' => '修改成功'
			]);
		}
		$res = Db::table('note')
				->where('id', $noteId)
				->where('creator_id', $creatorId)
				->where('deleted', 0)
				->update([
					'title' => $title,
					'cate_id' => $cateId,
					'content' => $content,
					'minContent' => $minContent
				]);
		return json([
			'status' => 200,
			'msg' => '修改成功'
		]);
	}
	public function list() {
		$creatorId = intval(input('get.creatorId'));
		$appid = trim(input('get.appid'));
		$search = trim(input('get.search'));
		$page = intval(input('get.page')); // 每页50条数据 下拉加载下一页
		$checkToken = Db::table('securet')
						->where('appid', $appid)
						->find();
		if (!$checkToken) {
			return json([
				'status' => 405,
				'msg' => '非法访问'
			]);
		}
		if (!$creatorId || !$page) {
			return json([
				'status' => 405,
				'msg' => '传参不能为空'
			]);
		}
		$type = intval(input('get.type'));
		if ($type == 2) {
			// date筛选
			$indexDate = trim(input('get.indexDate'));
			// var_dump($indexDate);
			// var_dump("'".$indexDate."%'");
			$list = Db::table('note')
					->alias('n')
					->field('n.*, c.cate_name')
					->leftJoin('cate c', 'n.cate_id = c.id')
					->where('n.creator_id', $creatorId)
					->where('n.deleted', 0)
					->where('n.create_at', 'like', $indexDate."%")
					->order('n.id', 'desc')
					->page($page, 100)
					->select();
			return json([
				'status' => 200,
				'msg' => 'success',
				'data' => $list
			]);
		}
		if ($search) {
			// 关键字查询 筛选标题or标签
			$list = Db::table('note')
					->alias('n')
					->field('n.*, c.cate_name')
					->leftJoin('cate c', 'n.cate_id = c.id')
					// ->where('n.creator_id', $creatorId)
					// ->where('n.deleted', 0)
					->whereOr([
						[
							['n.creator_id', 'eq', $creatorId],
							['n.deleted', 'eq', 0],
							['n.title', 'like', '%'.$search.'%']
						],
						[
							['n.creator_id', 'eq', $creatorId],
							['n.deleted', 'eq', 0],
							['c.cate_name', 'like', '%'.$search.'%']
						]
					])
					->order('n.id', 'desc')
					->page($page, 50)
					->select();

		} else {
			$list = Db::table('note')
					->alias('n')
					->field('n.*, c.cate_name')
					->leftJoin('cate c', 'n.cate_id = c.id')
					->where('n.creator_id', $creatorId)
					->where('n.deleted', 0)
					->order('n.id', 'desc')
					->page($page, 10)
					->select();
		}
		return json([
			'status' => 200,
			'msg' => 'success',
			'data' => $list
		]);
	}
	public function info() {
		$creatorId = intval(input('get.creatorId'));
		$appid = trim(input('get.appid'));
		$noteId = intval(input('get.noteId'));
		$checkToken = Db::table('securet')
						->where('appid', $appid)
						->find();
		if (!$checkToken) {
			return json([
				'status' => 405,
				'msg' => '非法访问'
			]);
		}
		if (!$creatorId || !$noteId) {
			return json([
				'status' => 405,
				'msg' => '传参不能为空'
			]);
		}
		$info = Db::table('note')
				->where('id', $noteId)
				->where('creator_id', $creatorId)
				->where('deleted', 0)
				->find();
		if ($info) {
			return json([
				'status' => 200,
				'msg' => 'success',
				'data' => $info
			]);
		}
		return json([
			'status' => 405,
			'msg' => '获取数据失败'
		]);
	}
}