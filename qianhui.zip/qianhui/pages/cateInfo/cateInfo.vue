<template>
	<view>
		<!-- // 适应刘海屏幕 -->
		<view class="top" :style="{backgroundColor: '#0FD690',height: iStatusBarHeight + 'px'}"></view>
		<view class="header">
			<view class="iconfont icon-undo" @click="toBack" style="margin-left: 15rpx;"></view>
			<view class="title">编辑标签</view>
			<!-- <view class="delete">
				<image src="../../static/tabBarIco/delete-2.jpg"></image>
			</view> -->
		</view>
		<view class="tag-block">
			<view class="tag-top">
				<view>标签名称：</view>
				<input class="tag-name" v-model="tagName" placeholder="请输入标签名称" />
			</view>
			<view :data-icon="icon" style="margin-left: 20rpx;">图标选择：{{choose}}</view>
			<view class="bottom">
				<image class="icon" @click="chooseIcon(index)" v-for="(i, index) in icons" :key="index" :src="i"></image>
			</view>
		</view>
		<view>
			<button type="primary" @click="sub">确认</button>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				tagName: '',
				icon: '',
				choose: '',
				icons: [
					'/static/img/1.jpg',
					'/static/img/2.jpg',
					'/static/img/3.jpg',
					'/static/img/4.jpg',
					'/static/img/5.jpg',
					'/static/img/6.jpg',
					'/static/img/7.jpg',
					'/static/img/8.jpg',
					'/static/img/9.jpg',
					'/static/img/10.jpg'
				],
				chooses: [
					'第一个图标',
					'第二个图标',
					'第三个图标',
					'第四个图标',
					'第五个图标',
					'第六个图标',
					'第七个图标',
					'第八个图标',
					'第九个图标',
					'第十个图标'
				],
				cateId: ''
			}
		},
		methods: {
			toBack() {
				uni.navigateBack({
				    delta: 2
				});
			},
			chooseIcon: function (index) {
				// console.log(index);
				if (parseInt(index) >= 0 && parseInt(index) <= 10) {
					this.choose = this.chooses[index];
					this.icon = this.icons[index];
				}
			},
			sub: function () {
				if (!this.cateId || !this.tagName || !this.icon) {
					uni.showToast({title:'输入不能为空',icon:'none',duration:1000});
					return ;
				}
				// var globalUser = uni.getStorageInfoSync('globalUser');
				// console.log(globalUser);
				// return ;
				var me = this;
				uni.request({
					url: me.serverUrl + '/note/cateupdate',
					method: 'POST',
					header: {
						'content-type': 'application/x-www-form-urlencoded'
					},
					data: {
						appid: me.appid,
						token: me.globalUser.token,
						creatorId: me.globalUser.id,
						cateName: me.tagName,
						icon: me.icon,
						cateId: me.cateId
					},
					success: function (res) {
						console.log(res);
						if (res.data.status == 200) {
							uni.showToast({
								title: res.data.msg,
								duration: 1000
							});
							setTimeout(function () {
								uni.switchTab({
									url: '/pages/cate/cate'
								});
							}, 1000);
							return ;
						}
						uni.showToast({
							title: res.data.msg,
							icon: 'none',
							duration: 1000
						});
					},
					fail: function () {
						uni.showToast({
							title: '请求失败',
							icon: 'none',
							duration: 1000
						});
					}
				});
				// console.log('submit');
				// console.log(this.icon);
				// console.log(this.choose);
				// console.log(this.tagName);
				// uni.showToast({
				// 	title: '编辑标签成功',
				// 	duration: 1000
				// });
				// setTimeout(function () {
				// 	uni.switchTab({
				// 		url: '/pages/cate/cate'
				// 	});
				// }, 1000);
			},
			checkLogin() {
				var globalUser = uni.getStorageSync('globalUser');
				if (!globalUser) {
					uni.navigateTo({
						url: '/pages/login/login'
					});
				}
			}
		},
		onLoad(e) {
			console.log(e);
			this.tagName = e.cateName;
			this.icon = e.icon;
			this.cateId = e.cateId;
			for(var i = 0; i < this.icons.length; i++) {
				if (this.icon == this.icons[i]) {
					this.choose = this.chooses[i];
					break;
				}
			}
			// var globalUser = uni.getStorageInfoSync('globalUser');
			// console.log(globalUser);
			// this.checkLogin();
			// 适应刘海屏幕 获取状态栏的高度
			this.iStatusBarHeight = uni.getSystemInfoSync().statusBarHeight;
			uni.loadFontFace({
				family: 'Pacifico',
				source: 'url("https://sungd.github.io/Pacifico.ttf")'
			})
		},
		onShow() {
			this.checkLogin();
			var globalUser = uni.getStorageSync('globalUser');
			// console.log(globalUser);
			this.globalUser = globalUser;
		}
	}
</script>

<style>
@import url('./cateInfo.css');
</style>
