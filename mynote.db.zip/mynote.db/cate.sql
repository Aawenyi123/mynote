/*
Navicat MySQL Data Transfer

Source Server         : local
Source Server Version : 50726
Source Host           : localhost:3306
Source Database       : mynote

Target Server Type    : MYSQL
Target Server Version : 50726
File Encoding         : 65001

Date: 2020-05-20 19:25:05
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for cate
-- ----------------------------
DROP TABLE IF EXISTS `cate`;
CREATE TABLE `cate` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cate_name` varchar(255) NOT NULL DEFAULT '' COMMENT '分类名称',
  `create_at` varchar(255) NOT NULL DEFAULT '0000-00-00 00:00:00',
  `creator_id` int(11) NOT NULL COMMENT '创建人id',
  `deleted` tinyint(2) NOT NULL DEFAULT '0' COMMENT '0 未删除 1 删除',
  `icon` varchar(255) NOT NULL COMMENT '图标',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of cate
-- ----------------------------
INSERT INTO `cate` VALUES ('1', 'ddwdwfwaw', '0000-00-00 00:00:00', '2', '0', '/static/img/3.jpg');
INSERT INTO `cate` VALUES ('2', 'test222', '2020-05-17 18:05:13', '2', '0', '/static/img/2.jpg');
INSERT INTO `cate` VALUES ('3', 'test222wwww', '2020-05-17 18:27:03', '1', '1', '/static/img/2.jpg');
