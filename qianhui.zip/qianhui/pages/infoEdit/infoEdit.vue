<template>
	<view>
		<!-- // 适应刘海屏幕 -->
		<view class="top" :style="{backgroundColor: '#0FD690',height: iStatusBarHeight + 'px'}"></view>
		<view class="header">
			<view class="title">修改个人信息</view>
		</view>
		<view class="info-block">
			<image :src="face" class="face"></image>
			<view class="info-lab">
				<view class="lab">用户名：</view>
				<input type="text" placeholder="请填写用户名..." v-model="name" />
			</view>
			<view class="info-lab">
				<view class="lab">手机号：</view>
				<input type="number" placeholder="请填写手机号..." v-model="tel"/>
			</view>
			<view class="info-lab">
				<view class="lab">密码：</view>
				<input type="password" placeholder="请填写密码..." v-model="pwd"/>
			</view>
			<view class="info-lab">
				<view class="lab">重复密码：</view>
				<input type="password" placeholder="请重复填写密码..." v-model="rePwd"/>
			</view>
			<view class="sub">
				<button type="primary" @click="sub">提交修改</button>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				statusBarHeight: 0,
				face: '',
				name: '',
				tel: '',
				pwd: '',
				rePwd: '',
				id: '',
				token: ''
			}
		},
		methods: {
			sub: function () {
				if (!this.name || !this.tel || !this.pwd || !this.rePwd) {
					uni.showToast({
						title: '输入框不能为空',
						icon: 'none',
						duration: 1000
					});
					return;
				}
				if (this.pwd != this.rePwd) {
					uni.showToast({
						title: '两次密码输入不一致',
						icon: 'none',
						duration: 1000
					});
					return;
				}
				var me = this;
				uni.request({
					url: me.serverUrl + '/note/userupdate',
					method: 'POST',
					header: {
						'content-type': 'application/x-www-form-urlencoded'
					},
					data: {
						id: me.id,
						token: me.token,
						appid: me.appid,
						userName: me.name,
						pwd: me.pwd,
						tel: me.tel
					},
					success: function (res) {
						console.log(res);
						if (res.data.status == 200) {
							uni.setStorageSync('globalUser', res.data.data);
							uni.showToast({
								title: res.data.msg,
								// icon: 'none',
								duration: 1000
							});
							setTimeout(function () {
								uni.switchTab({
									url: '/pages/me/me'
								});
							}, 1000);
							return ;
						}
						uni.showToast({
							title: res.data.msg,
							icon: 'none',
							duration: 1000
						});
					},
					fail: function () {
						uni.showToast({
							title: '请求失败',
							icon: 'none',
							duration: 1000
						});
					}
				});
				// return;
				// console.log('sub');
				// uni.showToast({
				// 	title: '提交成功',
				// 	duration: 1000
				// });
				// setTimeout(function () {
				// 	uni.switchTab({
				// 		url: '/pages/me/me'
				// 	});
				// }, 1000);
			},
			checkLogin() {
				var globalUser = uni.getStorageSync('globalUser');
				if (!globalUser) {
					uni.navigateTo({
						url: '/pages/login/login'
					});
				}
			}
		},
		onLoad() {
			// 适应刘海屏幕 获取状态栏的高度
			// console.log(uni.getSystemInfoSync());
			this.iStatusBarHeight = uni.getSystemInfoSync().statusBarHeight;
		},
		onShow() {
			this.checkLogin();
			var globalUser = uni.getStorageSync('globalUser');
			// console.log(globalUser);
			// this.uid = globalUser.id;
			this.name = globalUser.name;
			this.tel = globalUser.tel;
			this.face = globalUser.face;
			this.pwd = globalUser.pwd;
			this.rePwd = globalUser.pwd;
			this.id = globalUser.id;
			this.token = globalUser.token;
		}
	}
</script>

<style>
@import url('./infoEdit.css');
</style>
