/*
Navicat MySQL Data Transfer

Source Server         : local
Source Server Version : 50726
Source Host           : localhost:3306
Source Database       : mynote

Target Server Type    : MYSQL
Target Server Version : 50726
File Encoding         : 65001

Date: 2020-05-20 19:25:35
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for user
-- ----------------------------
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL COMMENT '用户名',
  `tel` char(11) NOT NULL COMMENT '手机号',
  `pwd` varchar(255) NOT NULL COMMENT '密码',
  `token` varchar(255) NOT NULL COMMENT '用户标识',
  `create_at` varchar(255) NOT NULL DEFAULT '0000-00-00 00:00:00',
  `face` varchar(255) DEFAULT '' COMMENT '头像',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of user
-- ----------------------------
INSERT INTO `user` VALUES ('1', 'zhangsan', '13333333333', '13333333333', '9caeb662a901c7b5651e46ad2b9427bb', '2020-05-17 15:26:43', '/static/img/1.jpg');
INSERT INTO `user` VALUES ('2', 'lisi', '17600903720', '123456', '1a2a99663bb0e8635e85160bf25d15f5', '2020-05-17 15:28:12', '/static/img/1.jpg');
