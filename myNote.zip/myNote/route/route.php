<?php
// +----------------------------------------------------------------------
// | ThinkPHP [ WE CAN DO IT JUST THINK ]
// +----------------------------------------------------------------------
// | Copyright (c) 2006~2018 http://thinkphp.cn All rights reserved.
// +----------------------------------------------------------------------
// | Licensed ( http://www.apache.org/licenses/LICENSE-2.0 )
// +----------------------------------------------------------------------
// | Author: liu21st <liu21st@gmail.com>
// +----------------------------------------------------------------------

Route::get('think', function () {
    return 'hello,ThinkPHP5!';
});

Route::get('hello/:name', 'index/hello');

Route::post('note/register', 'api/Account/register');
Route::post('note/login', 'api/Account/login');
Route::post('note/userupdate', 'api/Account/update');

Route::post('note/cateadd', 'api/Cate/add');
Route::post('note/catedel', 'api/Cate/delete');
Route::get('note/catelist', 'api/Cate/list');
Route::post('note/cateupdate', 'api/Cate/update');
Route::get('note/cateinfo', 'api/Cate/info');

Route::post('note/noteadd', 'api/Note/add');
Route::post('note/notedel', 'api/Note/delete');
Route::get('note/notelist', 'api/Note/list');
Route::post('note/noteupdate', 'api/Note/update');
Route::get('note/noteinfo', 'api/Note/info');

return [

];
