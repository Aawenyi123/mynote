<?php

/**
 * @Author: wenyi
 * @Date:   2020-05-17 17:18:40
 * @Email: m17600903720@163.com
 * @Tel: 17600903720
 * @Comment: comment...
 * @CreateTime: 2020-05-17 17:18:40
 */
namespace app\api\controller;
use think\Db;
use think\Controller;
class Cate extends Controller {
	public function add() {
		$cateName = trim(input('post.cateName'));
		$icon = trim(input('post.icon'));
		$appid = trim(input('post.appid'));
		$creatorId = intval(input('post.creatorId'));
		$token = trim(input('post.token'));
		$checkToken = Db::table('securet')
						->where('appid', $appid)
						->find();
		if(!$checkToken) {
			return json([
				'status' => 405,
				'msg' => '非法访问'
			]);
		}
		// 验证用户
		$user = Db::table('user')
				->where('id', $creatorId)
				->where('token', $token)
				->find();
		if (!$user) {
			return json([
				'status' => 405,
				'msg' => '非法用户访问'
			]);
		}
		if($cateName == '' || $icon == '') {
			return json([
				'status' => 405,
				'msg' => '传参不能为空'
			]);
		}
		$info = Db::table('cate')
				->where('cate_name', $cateName)
				->where('creator_id', $creatorId)
				->where('deleted', 0)
				->find();
		if ($info) {
			return json([
				'status' => 405,
				'msg' => '标签名已存在，不能重复添加'
			]);
		}
		$res = Db::table('cate')
				->insertGetId([
					'cate_name' => $cateName,
					'icon' => $icon,
					'creator_id' => $creatorId,
					'create_at' => date('Y-m-d H:i:s')
				]);
		if($res) {
			return json([
				'status' => 200,
				'msg' => '添加标签成功'
			]);
		}
		return json([
			'status' => 405,
			'msg' => '添加标签失败'
		]);
	}
	public function delete() {
		$cateId = intval(input('post.cateId'));
		$appid = trim(input('post.appid'));
		$creatorId = intval(input('post.creatorId'));
		$token = trim(input('post.token'));
		$checkToken = Db::table('securet')
						->where('appid', $appid)
						->find();
		if(!$checkToken) {
			return json([
				'status' => 405,
				'msg' => '非法访问'
			]);
		}
		if(!$cateId || !$creatorId || !$token) {
			return json([
				'status' => 405,
				'msg' => '传参不能为空'
			]);
		}
		// 验证用户
		$user = Db::table('user')
				->where('id', $creatorId)
				->where('token', $token)
				->find();
		if (!$user) {
			return json([
				'status' => 405,
				'msg' => '非法用户访问'
			]);
		}

		$res = Db::table('cate')
				->where('creator_id', $creatorId)
				->where('id', $cateId)
				->update([
					'deleted' => 1
				]);
		return json([
			'status' => 200,
			'msg' => '删除标签成功'
		]);
	}
	public function update() {
		$creatorId = intval(input('post.creatorId'));
		$appid = trim(input('post.appid'));
		$token = trim(input('post.token'));
		$cateId = intval(input('post.cateId'));
		$cateName = trim(input('post.cateName'));
		$icon = trim(input('post.icon'));
		$checkToken = Db::table('securet')
						->where('appid', $appid)
						->find();
		if(!$checkToken) {
			return json([
				'status' => 405,
				'msg' => '非法访问'
			]);
		}
		if(!$cateId || !$creatorId || !$token || !$cateName || !$icon) {
			return json([
				'status' => 405,
				'msg' => '传参不能为空'
			]);
		}
		// 验证用户
		$user = Db::table('user')
				->where('id', $creatorId)
				->where('token', $token)
				->find();
		if (!$user) {
			return json([
				'status' => 405,
				'msg' => '非法用户访问'
			]);
		}
		$info = Db::table('cate')
				->where('id', $cateId)
				->where('creator_id', $creatorId)
				->where('cate_name', $cateName)
				->where('icon', $icon)
				->where('deleted', 0)
				->find();
		if($info) {
			return json([
				'status' => 200,
				'msg' => '修改标签成功'
			]);
		}
		$info = Db::table('cate')
				->where('deleted', 0)
				->where('cate_name', $cateName)
				->where('creator_id', $creatorId)
				->select();
		if(count($info) == 1 && $info[0]['id'] != $cateId) {
			return json([
				'status' => 405,
				'msg' => '标签名重复，请检查'
			]);
		}
		$res = Db::table('cate')
				->where('deleted', 0)
				->where('creator_id', $creatorId)
				->where('id', $cateId)
				->update([
					'cate_name' => $cateName,
					'icon' => $icon
				]);
		return json([
			'status' => 200,
			'msg' => '修改标签成功'
		]);
	}
	public function list() {
		$creatorId = intval(input('get.creatorId'));
		$appid = trim(input('get.appid'));
		$checkToken = Db::table('securet')
						->where('appid', $appid)
						->find();
		if(!$checkToken) {
			return json([
				'status' => 405,
				'msg' => '非法访问'
			]);
		}
		if (!$creatorId) {
			return json([
				'status' => 405,
				'msg' => '传参不能为空'
			]);
		}
		$list = Db::table('cate')
				->where('creator_id', $creatorId)
				->where('deleted', 0)
				->order('id', 'desc')
				->select();
		return json([
			'status' => 200,
			'msg' => '获取标签列表成功',
			'data' => $list
		]);
	}
	public function info() {
		$creatorId = intval(input('get.creatorId'));
		$appid = trim(input('get.appid'));
		$cateId = intval(input('get.cateId'));
		$checkToken = Db::table('securet')
						->where('appid', $appid)
						->find();
		if (!$checkToken) {
			return json([
				'status' => 405,
				'msg' => '非法访问'
			]);
		}
		if (!$creatorId || !$cateId) {
			return json([
				'status' => 405,
				'msg' => '传参不能为空'
			]);
		}
		$info = Db::table('cate')
				->where('creator_id', $creatorId)
				->where('id', $cateId)
				->find();
		if ($info) {
			return json([
				'status' => 405,
				'msg' => 'success',
				'data' => $info
			]);
		}
		return json([
			'status' => 405,
			'msg' => '获取数据失败'
		]);
	}
}