<template>
	<view>
		<!-- // 适应刘海屏幕 -->
		<view class="top" :style="{backgroundColor: '#0FD690',height: iStatusBarHeight + 'px'}"></view>
		<view class="header">
			<view class="title">日历</view>
		</view>
		<uni-section :title="date" type="line"></uni-section>
		<view>
			<!-- 插入模式 -->
			<uni-calendar :selected="info.selected" :showMonth="false" @change="change" @monthSwitch="monthSwitch" />
		</view>
		<view class="noteList">
			<view class="note-date">
				{{indexDate}}
			</view>
			
			<view class="note-block" v-for="(note, index) in dateNotes" :key="index" @click="getInfo(note.id)" >
				<view class="tag-block">
					<image src="../../static/tabBarIco/cate-b.jpg" class="tag-icon"></image>
					<view class="tag-name">{{note.cate_name}}</view>
				</view>
				<view class="note-top">
					<view class="note-time">{{note.create_at.substr(11,8)}}</view>
					<view class="note-title">{{note.title}}</view>
				</view>
				<view class="note-content">
					{{note.minContent ? note.minContent.substr(0,20):''}}...
				</view>
			</view>
			
		</view>
	</view>
</template>

<script>
	import uniSection from '@/components/uni-section/uni-section.vue'
	import uniCalendar from '@/components/uni-calendar/uni-calendar.vue'
	export default {
		data() {
			return {
				date: '今天',
				indexDate: '',
				info: {
					date: '',
					startDate: '',
					endDate: '',
					lunar: true,
					range: true,
					insert: false,
					selected: []
				},
				dateNotes: []
			}
		},
		methods: {
			getInfo(id) {
				// console.log('跳转info页');
				uni.navigateTo({
					url: '../info/info?noteId=' + id
				});
			},
			monthSwitch(e) {
				console.log('monthSwitchs 返回:', e);
			},
			change(e) {
				console.log('change 返回:', e);
				console.log(e);
				this.indexDate = e.fulldate;
				// 加载指定天的数据
				this.loadDateNotes();
				// this.date = e.fulldate;
				// 模拟动态打卡
				// if (this.info.selected.length > 5) return
				// this.info.selected.push({
				// 	date: e.fulldate,
				// 	info: '打卡'
				// })
			},
			getNowDate() {
				var myDate = new Date;
				    var year = myDate.getFullYear(); //获取当前年
				    var mon = myDate.getMonth() + 1; //获取当前月
				    var date = myDate.getDate(); //获取当前日
				    // var h = myDate.getHours();//获取当前小时数(0-23)
				    // var m = myDate.getMinutes();//获取当前分钟数(0-59)
				    // var s = myDate.getSeconds();//获取当前秒
				    var week = myDate.getDay();
				    var weeks = ["星期日", "星期一", "星期二", "星期三", "星期四", "星期五", "星期六"];
				    // console.log(year, mon, date, weeks[week])
				    this.date = year + "年" + mon + "月" + date + "日  " + weeks[week];
					if (mon >= 10 && date >= 10) {
						this.indexDate = year + "-" + mon + "-" + date;
					}
					if (mon >= 10 && date < 10) {
						this.indexDate = year + "-" + mon + "-0" + date;
					}
					if (mon < 10 && date >= 10) {
						this.indexDate = year + "-0" + mon + "-" + date;
					}
					if (mon < 10 && date < 10) {
						this.indexDate = year + "-0" + mon + "-0" + date;
					}
					// 加载指定天的数据
					this.loadDateNotes();
			},
			checkLogin() {
				var globalUser = uni.getStorageSync('globalUser');
				if (!globalUser) {
					uni.navigateTo({
						url: '/pages/login/login'
					});
				}
			},
			loadDateNotes() {
				var me = this;
				uni.request({
					url: me.serverUrl + '/note/notelist',
					method: 'GET',
					data: {
						appid: me.appid,
						creatorId: me.globalUser.id,
						appid: me.appid,
						page: 1,
						search: '',
						type: 2,
						indexDate: me.indexDate
					},
					success: function (res) {
						console.log(res);
						if (res.data.status == 200) {
							// me.cateList = res.data.data;
							me.dateNotes = res.data.data;
							return false;
						}
						uni.showToast({title: res.data.msg, icon: 'none', duration: 1000});
					},
					fail: function () {
						uni.showToast({title: '请求失败', icon: 'none', duration: 1000});
					}
				});
			}
		},
		onLoad() {
			this.checkLogin();
			var globalUser = uni.getStorageSync('globalUser');
			this.globalUser = globalUser;
			// this.checkLogin();
			// 适应刘海屏幕 获取状态栏的高度
			this.iStatusBarHeight = uni.getSystemInfoSync().statusBarHeight;
			this.getNowDate();
			
		},
		components: {
			uniSection,
			uniCalendar
		},
		onReady() {
			this.$nextTick(() => {
				this.showCalendar = true
			})
			console.log(this.info);
			// TODO 模拟请求异步同步数据
			// setTimeout(() => {
			// 	this.info.selected = [{
			// 			date: '2019-08-20',
			// 			info: '打卡'
			// 		},
			// 		{
			// 			date: '2019-08-21',
			// 			info: '签到',
			// 			data: {
			// 				custom: '自定义信息',
			// 				name: '自定义消息头'
			// 			}
			// 		},
			// 		{
			// 			date: '2019-08-22',
			// 			info: '已打卡'
			// 		}
			// 	]
			// }, 500)
		},
		onShow() {
			
		}
	}
</script>

<style>
@import url('./date.css');
</style>
