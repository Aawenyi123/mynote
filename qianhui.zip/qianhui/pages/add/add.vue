<template>
	<view>
		<!-- // 适应刘海屏幕 -->
		<view class="top" :style="{backgroundColor: '#0FD690',height: iStatusBarHeight + 'px'}"></view>
		<view class="header">
			<view class="iconfont icon-undo" @click="toBack" style="margin-left: 15rpx;"></view>
			<view class="title">书写手记</view>
			<!-- <view class="delete">
				<image src="../../static/tabBarIco/delete-2.jpg"></image>
			</view> -->
			<view class="save" @click="sub">
				✔
			</view>
		</view>
		<view class="note-block">
			<view class="note-top">
				
				<!-- <view class="tag-name">工作</view> -->
				<picker @change="bindPickerChange" class="tag-name" :value="index" :range="array">
				        <image src="../../static/tabBarIco/cate-b.jpg" style="display: inline-block;" class="tag-icon"></image>
						<view class="uni-input" style="display: inline-block;margin-left: 10rpx;">{{nowCate}}</view>
				</picker>
				<!-- <image src="../../static/tabBarIco/delete-2.jpg" class="delete"></image> -->
			</view>
			<view class="note-center">
				<view class="note-title">
					标题：
				</view>
				<input class="note-name" v-model="noteName" placeholder="请输入标题" />
			</view>
			<view class='wrapper'>
				<view class='toolbar' @tap="format">
					<view class="iconfont icon-charutupian" @tap="insertImage"></view>
					<view :class="formats.align === 'left' ? 'ql-active' : ''" class="iconfont icon-zuoduiqi" data-name="align"
					 data-value="left"></view>
					<view :class="formats.align === 'center' ? 'ql-active' : ''" class="iconfont icon-juzhongduiqi" data-name="align"
					 data-value="center"></view>
					<view :class="formats.align === 'right' ? 'ql-active' : ''" class="iconfont icon-youduiqi" data-name="align"
					 data-value="right"></view>
					 <view :class="formats.list === 'ordered' ? 'ql-active' : ''" class="iconfont icon-youxupailie" data-name="list"
					  data-value="ordered"></view>
					 <view :class="formats.list === 'bullet' ? 'ql-active' : ''" class="iconfont icon-wuxupailie" data-name="list"
					  data-value="bullet"></view>
				</view>
			
				<editor id="editor" class="ql-container" placeholder="开始记录美好..." showImgSize showImgToolbar showImgResize
				 @statuschange="onStatusChange" :read-only="readOnly" @ready="onEditorReady">
				</editor>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				noteName: '',
				readOnly: false,
				formats: {},
				array: [],
				keys: [],
				index: 0,
				nowCate: ''
				// content: ''
			}
		},
		methods: {
			toBack() {
				uni.switchTab({
				    url: '/pages/index/index'
				});
			},
			bindPickerChange: function(e) {
			    // console.log('picker发送选择改变，携带值为', e.target.value);
			    this.index = e.target.value;
				this.nowCate = this.array[this.index];
			},
			readOnlyChange() {
				this.readOnly = !this.readOnly
			},
			onEditorReady() {
				uni.createSelectorQuery().select('#editor').context((res) => {
					this.editorCtx = res.context
				}).exec()
			},
			format(e) {
				let {
					name,
					value
				} = e.target.dataset
				if (!name) return
				// console.log('format', name, value)
				this.editorCtx.format(name, value)
			
			},
			onStatusChange(e) {
				const formats = e.detail
				this.formats = formats
			},
			insertImage() {
				uni.chooseImage({
					count: 1,
					success: (res) => {
						this.editorCtx.insertImage({
							src: res.tempFilePaths[0],
							alt: '图像',
							success: function() {
								console.log('insert image success')
							}
						})
					}
				})
			},
			checkLogin() {
				var globalUser = uni.getStorageSync('globalUser');
				if (!globalUser) {
					uni.navigateTo({
						url: '/pages/login/login'
					});
				}
			},
			getCateList: function () {
				
				this.array = [];
				this.keys = [];
				var me = this;
				uni.request({
					url: me.serverUrl + '/note/catelist',
					method: 'GET',
					data: {
						appid: me.appid,
						creatorId: me.globalUser.id
					},
					success: function (res) {
						// console.log(res);
						if (res.data.status == 200) {
							// me.array = res.data.data;
							for (var i = 0; i < res.data.data.length; i++) {
								me.keys[i] = res.data.data[i].id;
								me.array[i] = res.data.data[i].cate_name;
							}
							if (me.array.length > 0) {
								me.nowCate = me.array[me.index];
							}
							// setTimeout(function (){
								// me.noteName = '';
								// me.editorCtx.setContents({
								// 	html: ''
								// });
							// }, 200);
							
							// console.log(me.nowCate);
							return false;
						}
						uni.showToast({title: res.data.msg, icon: 'none', duration: 1000});
					},
					fail: function () {
						uni.showToast({title: '请求失败', icon: 'none', duration: 1000});
					}
				});
			},
			sub: function () {
				if (!this.noteName) {
					uni.showToast({title: '标题未填写', icon: 'none', duration: 1000});
					return;
				}
				if (!this.nowCate) {
					uni.showToast({title: '未选择标签', icon: 'none', duration: 1000});
					return;
				}
				var obj = {
					title: this.noteName,
					cateId: this.keys[this.index],
					cateName: this.nowCate,
					appid: this.appid,
					creatorId: this.globalUser.id,
					token: this.globalUser.token
				}
				// console.log(obj);
				var me = this;
				this.editorCtx.getContents({
					success: function (res) {
						// console.log(res);
						me.content = res.html;
						me.minContent = res.text;
					}
				});
				// sleep(1000);
				setTimeout(function () {
					obj.content = me.content;
					obj.minContent = me.minContent;
					// console.log(me.content);
					// console.log(me.minContent);
					// console.log(obj);
					uni.request({
						url: me.serverUrl + '/note/noteadd',
						method: 'POST',
						header: {
							'content-type': 'application/x-www-form-urlencoded'
						},
						data: obj,
						success: function (res) {
							console.log(res);
							if (res.data.status == 200) {
								uni.showToast({
									title: res.data.msg,
									duration: 1000
								});
								setTimeout(function () {
									me.noteName = '';
									me.editorCtx.setContents({
										html: ''
									});
									me.index = 0;
									uni.switchTab({
										url: '/pages/index/index'
									});
								}, 1000);
								return ;
							}
							uni.showToast({
								title: res.data.msg,
								icon: 'none',
								duration: 1000
							});
						},
						fail: function () {
							uni.showToast({
								title: '请求失败',
								icon: 'none',
								duration: 1000
							});
						}
					});
				}, 500);
				// console.log(obj.minContent);
				// return;
				
			}
		},
		onLoad() {
			// this.checkLogin();
			// 适应刘海屏幕 获取状态栏的高度
			this.iStatusBarHeight = uni.getSystemInfoSync().statusBarHeight;
			uni.loadFontFace({
				family: 'Pacifico',
				source: 'url("https://sungd.github.io/Pacifico.ttf")'
			})
			this.checkLogin();
			var globalUser = uni.getStorageSync('globalUser');
			this.globalUser = globalUser;
			
			// this.editorCtx.setContents({
			// 	html: ''
			// });
			this.getCateList();
		},
		onShow() {
			
			
			
		}
	}
</script>

<style>
@import url('./add.css');
.ql-container {
		box-sizing: border-box;
		padding: 12px 15px;
		width: 90%;
		min-height: 30vh;
		height: auto;
		background: #fff;
		margin-top: 20px;
		font-size: 16px;
		line-height: 1.5;
	}
</style>
