/*
Navicat MySQL Data Transfer

Source Server         : local
Source Server Version : 50726
Source Host           : localhost:3306
Source Database       : mynote

Target Server Type    : MYSQL
Target Server Version : 50726
File Encoding         : 65001

Date: 2020-05-20 19:25:13
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for note
-- ----------------------------
DROP TABLE IF EXISTS `note`;
CREATE TABLE `note` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL COMMENT '手记标题',
  `content` text NOT NULL COMMENT '内容',
  `cate_id` int(11) NOT NULL COMMENT '分类id',
  `creator_id` int(11) NOT NULL COMMENT '创建人id',
  `create_at` varchar(255) NOT NULL DEFAULT '0000-00-00 00:00:00',
  `deleted` tinyint(2) NOT NULL DEFAULT '0' COMMENT '0 未删除 1删除',
  `minContent` text COMMENT '内容文本',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of note
-- ----------------------------
INSERT INTO `note` VALUES ('1', '标题1', '这里是我写的内容', '1', '2', '2020-05-18 11:27:47', '0', null);
INSERT INTO `note` VALUES ('2', 'dww2', 'fgyhyjju', '1', '2', '2020-05-18 11:28:09', '0', null);
INSERT INTO `note` VALUES ('3', '标题2wd', '这里是我写的dwadwdawdw内容', '2', '2', '2020-05-18 11:28:20', '0', null);
INSERT INTO `note` VALUES ('4', '标题2wd dwe22d', '这里是我写的dwadwda大洼大洼wdw内容', '2', '2', '2020-05-18 11:28:29', '0', null);
INSERT INTO `note` VALUES ('5', '标题1wd dwe22ddwdw大洼大洼', '这里是我写的dwadw谁说的对外人啊等我da大洼大洼wdw内容', '1', '2', '2020-05-18 11:28:47', '1', null);
