/*
Navicat MySQL Data Transfer

Source Server         : local
Source Server Version : 50726
Source Host           : localhost:3306
Source Database       : mynote

Target Server Type    : MYSQL
Target Server Version : 50726
File Encoding         : 65001

Date: 2020-05-20 19:25:22
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for securet
-- ----------------------------
DROP TABLE IF EXISTS `securet`;
CREATE TABLE `securet` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'id',
  `appid` char(50) NOT NULL DEFAULT '' COMMENT 'appid标识',
  `created_at` varchar(255) NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of securet
-- ----------------------------
INSERT INTO `securet` VALUES ('1', 'bc4512dc898f8a8832c5f2a520b66435', '0000-00-00 00:00:00');
