<template>
	<view class="page" :style="{height: screenHeight + 'px'}">
	<!-- <view class="page"> -->
		<!-- // 适应刘海屏幕 -->
		<view class="top" :style="{backgroundColor: '#0FD690',height: iStatusBarHeight + 'px'}"></view>
		<view class="header">
			<view class="title">登录</view>
		</view>
		<view class="login-info">
			<view class="lab-block">
				<view class="lab">账户 </view>
				<input type="text" v-model="account" placeholder="请输入用户名/手机号"/>
			</view>
			<view class="lab-block">
				<view class="lab">密码 </view>
				<input type="password" v-model="pwd" placeholder="请输入密码"/>
			</view>
		</view>
		<view class="sub">
			<button type="primary" size="mini" @click="sub">登录</button>
			<button type="normal" size="mini" @click="reg">注册</button>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				account: '',
				pwd: ''
			}
		},
		methods: {
			sub: function () {
				if (!this.account || !this.pwd) {
					uni.showToast({
						title: '输入框不能为空',
						icon: 'none',
						duration: 1000
					});
					return;
				}
				
				var me = this;
				uni.request({
					url: me.serverUrl + '/note/login',
					data: {
						account: me.account,
						pwd: me.pwd,
						appid: me.appid
					},
					method: 'POST',
					header: {
						'content-type': 'application/x-www-form-urlencoded', 
					},
					success: (res) => {
						console.log(res);
						if (res.data.status == 200) {
							uni.setStorageSync('globalUser', res.data.data);
							uni.showToast({
								title: '登录成功',
								duration: 1000
							});
							setTimeout(function () {
								uni.switchTab({
									url: '/pages/index/index'
								});
							}, 1000);
							return;
						}
						uni.showToast({
							title: res.data.msg,
							icon: 'none',
							duration: 1000
						});
					},
					fail: function (res) {
						uni.showToast({
							title: '请求失败',
							icon: 'none',
							duration: 1000
						});
					}
				})
				// var obj = {
				// 	name: this.account,
				// 	pwd: this.pwd
				// };
				// uni.setStorageSync('globalUser', obj);
				// uni.showToast({
				// 	title: '登录成功',
				// 	duration: 1000
				// });
				// setTimeout(function () {
				// 	uni.switchTab({
				// 		url: '/pages/index/index'
				// 	});
				// }, 1000);
			},
			reg: function () {
				uni.navigateTo({
					url: '/pages/reg/reg'
				});
			}
		},
		onLoad() {
			// 适应刘海屏幕 获取状态栏的高度
			this.iStatusBarHeight = uni.getSystemInfoSync().statusBarHeight;
			// 获取屏幕的高度 填充背景色
			this.screenHeight = uni.getSystemInfoSync().screenHeight;
		}
	}
</script>

<style>
@import url('./login.css');
</style>
