<template>
	<view class="page" :style="{height: screenHeight + 'px'}">
	<!-- <view class="page"> -->
		<!-- // 适应刘海屏幕 -->
		<view class="top" :style="{backgroundColor: '#0FD690',height: iStatusBarHeight + 'px'}"></view>
		<view class="header">
			<view class="title">注册</view>
		</view>
		<view class="login-info">
			<view class="lab-block">
				<view class="lab">用户名 </view>
				<input type="text" v-model="name" placeholder="请输入用户名"/>
			</view>
			<view class="lab-block">
				<view class="lab">手机号 </view>
				<input type="number" v-model.number="tel" placeholder="请输入手机号"/>
			</view>
			<view class="lab-block">
				<view class="lab">密码 </view>
				<input type="password" v-model="pwd" placeholder="请输入密码"/>
			</view>
			<view class="lab-block">
				<view class="lab">重复密码 </view>
				<input type="password" v-model="rePwd" placeholder="请重复输入密码"/>
			</view>
		</view>
		<view class="sub">
			<button type="normal" size="mini" @click="login">登录</button>
			<button type="primary" size="mini" @click="sub">注册</button>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				name: '',
				tel: '',
				pwd: '',
				rePwd: ''
			}
		},
		methods: {
			sub: function () {
				if (!this.name || !this.tel || !this.pwd || !this.rePwd) {
					uni.showToast({
						title: '输入框不能为空',
						icon: 'none',
						duration: 1000
					});
					return;
				}
				if (this.pwd != this.rePwd) {
					uni.showToast({
						title: '两次输入的密码不一致',
						icon: 'none',
						duration: 1000
					});
					return;
				}
				var me = this;
				uni.request({
					url: me.serverUrl + '/note/register',
					method: 'POST',
					header: {
						'content-type' : 'application/x-www-form-urlencoded'
					},
					data: {
						name: me.name,
						tel: me.tel,
						pwd: me.pwd,
						appid: me.appid
					},
					success: function (res) {
						console.log(res);
						if (res.data.status == 200) {
							uni.setStorageSync('globalUser', res.data.data);
							uni.showToast({
								title: res.data.msg,
								icon: 'none',
								duration: 1000
							});
							setTimeout(function () {
								uni.switchTab({
									url: '/pages/index/index'
								});
							}, 1000);
							return;
						}
						uni.showToast({
							title: res.data.msg,
							icon: 'none',
							duration: 1000
						});
					},
					fail: function (res) {
						uni.showToast({
							title: '请求失败',
							icon: 'none',
							duration: 1000
						});
					}
				});
				// return;
				// // var obj = {
				// // 	name: this.name,
				// // 	tel: this.tel,
				// // 	pwd: this.pwd,
				// // 	rePwd: this.rePwd
				// // };
				// // uni.setStorageSync('globalUser', obj);
				// uni.showToast({
				// 	title: '注册成功',
				// 	duration: 1000
				// });
				// setTimeout(function () {
				// 	uni.switchTab({
				// 		url: '/pages/index/index'
				// 	});
				// }, 1000);
			},
			login: function () {
				uni.navigateTo({
					url: '/pages/login/login'
				});
			}
		},
		onLoad() {
			// 适应刘海屏幕 获取状态栏的高度
			this.iStatusBarHeight = uni.getSystemInfoSync().statusBarHeight;
			// 获取屏幕的高度 填充背景色
			this.screenHeight = uni.getSystemInfoSync().screenHeight;
		}
	}
</script>

<style>
@import url('./reg.css');
</style>
