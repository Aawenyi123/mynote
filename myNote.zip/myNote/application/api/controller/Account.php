<?php

/**
 * @Author: wenyi
 * @Date:   2020-05-17 12:09:25
 * @Email: m17600903720@163.com
 * @Tel: 17600903720
 * @Comment: comment...
 * @CreateTime: 2020-05-17 12:09:25
 */
namespace app\api\controller;
use think\Controller;
use think\Db;
class Account extends Controller {
	// note注册
	public function register() {
		// return 1;
		$name = trim(input('post.name'));
		$tel = intval(input('post.tel'));
		$pwd = trim(input('post.pwd'));
		$appid = trim(input('post.appid'));
		$checkToken = Db::table('securet')->where('appid', $appid)->find();
		// var_dump($appid);
		if (!$checkToken) {
			return json([
				'status' => 405,
				'msg' => '非法访问'
			]);
		}
		if ($name == '' || $tel ==  0 || $pwd == '') {
			return json([
				'status' => 405,
				'msg' => '传参不能为空，请检查'
			]);
		}
		if (strlen($tel) != 11 || !preg_match("/^1[34578]\d{9}$/", $tel)) {
			return json([
				'status' => 405,
				'msg' => '手机号格式不对，请检查'
			]);
		}
		$infoByTel = Db::table('user')
			->where('tel', $tel)
			->find();
		if($infoByTel) {
			return json([
				'status' => 405,
				'msg' => '手机号已存在，不能重复注册'
			]);
		}
		$infoByName = Db::table('user')
						->where('name', $name)
						->find();
		if ($infoByName) {
			return json([
				'status' => 405,
				'msg' => '用户名已存在，不能重复注册'
			]);
		}
		$token = md5(date('YmdHis').rand(10000, 99999));
		$res = Db::table('user')
				->insertGetId([
					'name' => $name,
					'tel' => $tel,
					'pwd' => $pwd,
					'create_at' => date('Y-m-d H:i:s'),
					'token' => $token,
					'face' => '/static/img/1.jpg'
				]);
		if ($res) {
			return json([
				'status' => 200,
				'msg' => '注册成功',
				'data' => [
					'name' => $name,
					'tel' => $tel,
					'pwd' => $tel,
					'create_at' => date('Y-m-d H:i:s'),
					'token' => $token,
					'face' => '/static/img/1.jpg',
					'id' => $res
				]
			]);
		}
		return json([
			'status' => 500,
			'msg' => '注册失败'
		]);

	}
	// 登录
	public function login() {
		$account = trim(input('post.account'));
		$pwd = trim(input('post.pwd'));
		$appid = trim(input('post.appid'));
		$checkToken = Db::table('securet')->where('appid', $appid)->find();
		if (!$checkToken) {
			return json([
				'status' => 405,
				'msg' => '非法访问'
			]);
		}
		if($account == '' || $pwd == '') {
			return json([
				'status' => 405,
				'msg' => '传参不能为空，请检查'
			]);
		}
		$info = Db::table('user')
					->whereOr([
						[
							['name','eq', $account],
							['pwd','eq', $pwd]
						],
						[
							['tel', 'eq', $account],
							['pwd', 'eq', $pwd]
						]
					])->find();
		if ($info) {
			return json([
				'status' => 200,
				'msg' => '登录成功',
				'data' => $info 
			]);
		}
		return json([
			'status' => 405,
			'msg' => '账户或密码错误'
		]);
	}
	public function update() {
		$id = intval(input('post.id'));
		$token = trim(input('post.token'));
		$appid = trim(input('post.appid'));
		$userName = trim(input('post.userName'));
		$tel = intval(input('post.tel'));
		$pwd = trim(input('post.pwd'));
		// return 1;
		$checkToken = Db::table('securet')
						->where('appid', $appid)
						->find();
		if(!$checkToken) {
			return json([
				'status' => 405,
				'msg' => '非法访问'
			]);
		}
		if (!$id || !$token || !$userName || !$tel || !$pwd) {
			return json([
				'status' => 405,
				'msg' => '传参不能为空'
			]);
		}
		if (strlen($tel) != 11 || !preg_match("/^1[34578]\d{9}$/", $tel)) {
			return json([
				'status' => 405,
				'msg' => '手机号格式不对，请检查'
			]);
		}
		// 验证用户
		$user = Db::table('user')
				->where('id', $id)
				->where('token', $token)
				->find();
		if (!$user) {
			return json([
				'status' => 405,
				'msg' => '非法用户访问'
			]);
		}
		$info = Db::table('user')
				->where('id', $id)
				->where('token', $token)
				->where('name', $userName)
				->where('tel', $tel)
				->where('pwd', $pwd)
				->find();
		if ($info) {
			// 可以查询到 用户信息未修改
			return json([
				'status' => 200,
				'msg' => '信息修改完成',
				'data' => $info
			]);
		}
		// return 1;
		$infoByName = Db::table('user')
						->where('name', $userName)
						->find();
		if ($infoByName && $id != $infoByName['id']) {
			return json([
				'status' => 405,
				'msg' => '用户名重复，请检查'
			]);
		}
		$infoByTel = Db::table('user')
						->where('tel', $tel)
						->find();
		if ($infoByTel && $id != $infoByTel['id']) {
			return json([
				'status' => 405,
				'msg' => '手机号重复，请检查'
			]);
		}
		$res = Db::table('user')
				->where('id', $id)
				->update([
					'name' => $userName,
					'tel' => $tel,
					'pwd' => $pwd
				]);
		return json([
			'status' => 200,
			'msg' => '信息修改完成',
			'data' => [
				'id' => $id,
				'face' => $user['face'],
				'name' => $userName,
				'tel' => $tel,
				'pwd' => $pwd,
				'token' => $token
			]
		]);
	}
}