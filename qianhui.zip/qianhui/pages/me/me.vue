<template>
	<view class="page">
		<!-- // 适应刘海屏幕 -->
		<view class="top" :style="{backgroundColor: '#0FD690',height: iStatusBarHeight + 'px'}"></view>
		<view class="header">
			<view class="title">个人信息</view>
		</view>
		<view class="me-block">

				<image :src="face" class="face"></image>
				<!-- <image src="/static/icos/settings.png" class="set"></image> -->

			<view>
				
				<view class="me-id">
					ID：{{uid}}
				</view>
				
				<view class="me-tel">
					tel：{{tel}}
				</view>
				<view class="me-name">
					用户名：{{uname}}
				</view>
			</view>
			<image src="/static/icos/settings.png" class="set" @click="set"></image>
		</view>
		<view class="logout">
			<button type="warn" @click="logout">退出登录</button>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				iStatusBarHeight: 0,
				totalHeight: 0,
				uid: '',
				tel: '',
				uname: '',
				face: '/static/img/1.jpg'
			}
		},
		methods: {
			logout: function (){
				console.log('logout');
				uni.removeStorageSync('globalUser');
				uni.showToast({
					title: '退出成功',
					duration: 1000
				});
				setTimeout(function () {
					uni.navigateTo({
						url: '/pages/login/login'
					});
				}, 1000);
			},
			set: function () {
				uni.navigateTo({
					url: '/pages/infoEdit/infoEdit'
				});
			},
			checkLogin() {
				var globalUser = uni.getStorageSync('globalUser');
				if (!globalUser) {
					uni.navigateTo({
						url: '/pages/login/login'
					});
				}
			}
		},
		onLoad() {
			this.checkLogin();
			// 适应刘海屏幕 获取状态栏的高度
			// console.log(uni.getSystemInfoSync());
			this.iStatusBarHeight = uni.getSystemInfoSync().statusBarHeight;
			// totalHeight
			
		},
		onShow() {
			this.checkLogin();
			var globalUser = uni.getStorageSync('globalUser');
			// console.log(globalUser);
			this.uid = globalUser.id;
			this.uname = globalUser.name;
			this.tel = globalUser.tel;
			this.face = globalUser.face;
		}
	}
</script>

<style>
@import url('./me.css');
</style>
