<template>
	<view>
		<!-- // 适应刘海屏幕 -->
		<view class="top" :style="{backgroundColor: '#0FD690',height: iStatusBarHeight + 'px'}"></view>
		<view class="header">
			
			<view class="title">
				全部标签（{{cateList.length}}）
			</view>
			<view class="add" @click="addCate">
				+
			</view>
		</view>
		<view class="tag-list">
			<view class="tag-block" v-for="(cate, index) in cateList" :key="index" @click="toInfo(index)">
				<image class="icon" :src="cate.icon"></image>
				<view>{{cate.cate_name}}</view>
				<image src="../../static/tabBarIco/delete.jpg" class="del" @click.stop="del(cate.id)"></image>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				// totalNum: cate,
				cateList: [
					
				],
				token: '',
				creatorId: ''
			}
		},
		methods: {
			addCate: function () {
				// cesjo
				// ceshiceshi
				uni.navigateTo({
					url: '../addCate/addCate'
				});
			},
			toInfo(index) {
				var info = this.cateList[index];
				console.log('/pages/cateInfo/cateInfo?cateId=' ,
					+ info.id + '&cateName=' + info.cate_name 
					+ '&icon=' + info.icon);
				uni.navigateTo({
					url: '/pages/cateInfo/cateInfo?cateId=' 
					+ info.id + '&cateName=' + info.cate_name 
					+ '&icon=' + info.icon
				});
			},
			checkLogin() {
				var globalUser = uni.getStorageSync('globalUser');
				if (!globalUser) {
					uni.navigateTo({
						url: '/pages/login/login'
					});
				}
			},
			del(cateId) {
				// console.log(cateId);
				var me = this;
				uni.request({
					url: me.serverUrl + '/note/catedel',
					method: 'POST',
					header: {
						'content-type': 'application/x-www-form-urlencoded'
					},
					data: {
						appid: me.appid,
						creatorId: me.creatorId,
						token: me.token,
						cateId: cateId
					},
					success: function (res) {
						console.log(res);
						if (res.data.status == 200) {
							// me.cateList = res.data.data;
							uni.showToast({title: res.data.msg, duration: 1000});
							me.loadCateList();
							return false;
						}
						uni.showToast({title: res.data.msg, icon: 'none', duration: 1000});
					},
					fail: function () {
						uni.showToast({title: '请求失败', icon: 'none', duration: 1000});
					}
				});
			},
			loadCateList() {
				var globalUser = uni.getStorageSync('globalUser');
				var me = this;
				uni.request({
					url: me.serverUrl + '/note/catelist',
					method: 'GET',
					data: {
						appid: me.appid,
						creatorId: globalUser.id
					},
					success: function (res) {
						console.log(res);
						if (res.data.status == 200) {
							me.cateList = res.data.data;
							return false;
						}
						uni.showToast({title: res.data.msg, icon: 'none', duration: 1000});
					},
					fail: function () {
						uni.showToast({title: '请求失败', icon: 'none', duration: 1000});
					}
				});
			}
		},
		onLoad() {
			// this.checkLogin();
			// 适应刘海屏幕 获取状态栏的高度
			this.iStatusBarHeight = uni.getSystemInfoSync().statusBarHeight;
		},
		onShow() {
			this.checkLogin();
			this.loadCateList();
			var globalUser = uni.getStorageSync('globalUser');
			this.token = globalUser.token;
			this.creatorId = globalUser.id;
		}
	}
</script>

<style>
@import url('./cate.css');
</style>
